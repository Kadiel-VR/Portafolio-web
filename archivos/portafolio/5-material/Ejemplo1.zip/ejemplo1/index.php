<?php include('templates/header.php'); ?>

<h2>Bienvenidos al registro de ejemplo</h2>
<p>Please <a href="register.php">register</a> to continue.</p>

<?php include('templates/footer.php'); ?>
