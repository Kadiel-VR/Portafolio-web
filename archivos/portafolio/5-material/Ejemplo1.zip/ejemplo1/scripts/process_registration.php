<?php
include('../includes/config.php');

// Obtener datos del formulario
$username = $_POST['username'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Encriptar la contraseña

// Crear la consulta SQL
$sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";

// Ejecutar la consulta y verificar si fue exitosa
if (mysqli_query($conn, $sql)) {
    echo "Registration successful!";
} else {
    echo "Error: " . mysqli_error($conn);
}

// Cerrar la conexión
mysqli_close($conn);
?>
