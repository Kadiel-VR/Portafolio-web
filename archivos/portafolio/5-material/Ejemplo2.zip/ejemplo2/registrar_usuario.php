<?php
require_once 'clases/Usuario.php'; // Incluimos la clase Usuario
require_once 'clases/Database.php'; // Incluimos la clase Database

// Obtener la conexión a la base de datos
$database = new Database(); // Creamos un objeto Database
$db = $database->getConnection(); // Obtenemos la conexión

// Crear un nuevo objeto Usuario
$usuario = new Usuario($db); // Pasamos la conexión al constructor de Usuario

// Asignar los valores del formulario a las propiedades del objeto
$usuario->nombre = $_POST['nombre']; // Asignar el nombre recibido del formulario
$usuario->email = $_POST['email']; // Asignar el email recibido del formulario
$usuario->contrasena = $_POST['contrasena']; // Asignar la contraseña recibida del formulario

// Registrar el usuario y mostrar un mensaje de éxito o error
if ($usuario->registrar()) {
    echo "Registro exitoso."; // Mensaje de éxito
} else {
    echo "Error al registrar el usuario."; // Mensaje de error
}
?>
