<?php
require_once 'Database.php'; // Incluimos la clase de conexión a la base de datos

class Usuario {
    private $conn; // Almacenará la conexión a la base de datos
    private $table_name = "usuarios"; // Nombre de la tabla de usuarios

    public $nombre; // Propiedad pública para almacenar el nombre del usuario
    public $email; // Propiedad pública para almacenar el correo electrónico del usuario
    public $contrasena; // Propiedad pública para almacenar la contraseña del usuario

    // Constructor que recibe la conexión a la base de datos
    public function __construct($db) {
        $this->conn = $db; // Inicializamos la conexión
    }

    // Método para registrar un nuevo usuario en la base de datos
    public function registrar() {
        // Consulta SQL para insertar un nuevo registro
        $query = "INSERT INTO " . $this->table_name . " (nombre, email, contrasena) VALUES (:nombre, :email, :contrasena)";

        // Preparar la consulta
        $stmt = $this->conn->prepare($query);

        // Sanitizar los datos de entrada para prevenir inyección SQL
        $this->nombre = htmlspecialchars(strip_tags($this->nombre));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->contrasena = htmlspecialchars(strip_tags($this->contrasena));

        // Enlazar los valores a la consulta SQL
        $stmt->bindParam(':nombre', $this->nombre);
        $stmt->bindParam(':email', $this->email);

        // Hash de la contraseña antes de almacenarla en la base de datos
        $password_hash = password_hash($this->contrasena, PASSWORD_BCRYPT);
        $stmt->bindParam(':contrasena', $password_hash);

        // Ejecutar la consulta y devolver el resultado
        if ($stmt->execute()) {
            return true; // Retornar verdadero si el registro es exitoso
        }

        return false; // Retornar falso si hay un error
    }
}
?>
