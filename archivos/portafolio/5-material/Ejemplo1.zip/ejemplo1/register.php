<?php include('templates/header.php'); ?>

<h2>Register</h2>
<form action="scripts/process_registration.php" method="POST">
    <label for="username">Username:</label>
    <input type="text" id="username" name="username" required>
    
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required>
    
    <label for="password">Password:</label>
    <input type="password" id="password" name="password" required>
    
    <input type="submit" value="Register">
</form>

<?php include('templates/footer.php'); ?>
